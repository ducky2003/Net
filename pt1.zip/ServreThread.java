package pt1;

public class ServreThread {

}
