package datetime;

import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Scanner;

public class ServerThread extends Thread {
	private static ServerSocket serverSocket;
	private static Socket socket;
	@Override
	public void run() {
		try {
			Scanner inServer = new Scanner(socket.getInputStream());
			PrintWriter outServer = new PrintWriter(socket.getOutputStream(),true);
			String s = inServer.nextLine();
			Calendar calen = Calendar.getInstance();
			SimpleDateFormat date = new SimpleDateFormat("dd-MM-yyyy");
			SimpleDateFormat time = new SimpleDateFormat("hh-mm-ss");
			String kq;
			if(s.equalsIgnoreCase("date")) {
				kq = date.format(calen.getTime());
			} else {
				kq = time.format(calen.getTime());
			}
			outServer.println(kq);
			socket.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void main(String[] args) throws Exception {
		serverSocket = new ServerSocket(3636);
		while(true) {
			socket = serverSocket.accept();
			ServerThread st = new ServerThread();
			st.start();
		}
	}
}
