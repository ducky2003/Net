package loop;

import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class Client {
	public static void main(String[] args) throws Exception {
		Socket socket = new Socket("localhost", 3636);
		
		Scanner inClient = new Scanner(socket.getInputStream());
		PrintWriter outClient = new PrintWriter(socket.getOutputStream(),true);
		
		Scanner input = new Scanner(System.in);
		
		System.out.println("Nhap he so a:");
        int a = input.nextInt();
        
        System.out.println("Nhap he so b:");
        int b = input.nextInt();
        
       
        outClient.println(a + " " + b);
		String kq = inClient.nextLine();
		
		System.out.println("ket qua: " + kq);
		socket.close();
	}

}
